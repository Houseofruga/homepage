repo: Houseofruga/homepage
branch: main
path: /

## Last sync
date: 2026-08-23T00:00:00Z
tree: 8feb68125835

### Updated in this project
- Redesigned homepage: two-column editorial split (sticky product rail + story stage)
- Rail = TrailWatch (live, blue #4242FF) over five muted "reserved · soon" slots
- Bold uppercase Clash Display thesis with word-rise reveal; Satoshi body, JetBrains Mono labels
- Placeholder blocks: studio narrative, ethos bullets, three team photos (image-slot)

## Screen map
| Project screen | Repo source files |
| --- | --- |
| House of Ruga.dc.html | index.html (palette, structure), trailwatch/index.html (TrailWatch copy), houseofruga-logo.svg (rail mark) |
